- 使用 container，並建立一個一列三欄的版型，xs、md 改變版型。

```html
<!-- 選單結構使用以下 -->
<nav class="nav">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Works</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
</nav>
```